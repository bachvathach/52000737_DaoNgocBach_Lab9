using StudentServiceLib;
using System.Security.Cryptography.X509Certificates;

namespace StudentTest
{
    [TestClass]
    public class TestStudent
    {
        //Test range of score
        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void scoreHiger11()
        {
            Student student = new Student();
            student.Score = 11;
        }

        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void scoreLower0()
        {
            Student student = new Student();
            student.Score = -1;
        }

        [TestMethod]    
        public void scoreInRangeZeroAndTen()
        {
            Student student = new Student();
            student.Score = 5;
        }



        // Test getLetterScore() function
        [TestMethod]
        public void getLetterScore9_ShouldReturn_A()
        {
            Student student = new Student();
            student.Score = 9;
            char letterScore = student.getLetterScore();

            Assert.AreEqual('A', letterScore);
        }

        [TestMethod]
        public void getLetterScore7_ShouldReturn_B()
        {
            Student student = new Student();
            student.Score = 7;
            char letterScore = student.getLetterScore();

            Assert.AreEqual('B', letterScore);
        }

        [TestMethod]
        public void getLetterScore5_ShouldReturn_C()
        {
            Student student = new Student();
            student.Score = 5;
            char letterScore = student.getLetterScore();

            Assert.AreEqual('C', letterScore);
        }

        [TestMethod]
        public void getLetterScoreFiveAndHalf_ShouldReturn_C()
        {
            Student student = new Student();
            student.Score = 5.5;
            char letterScore = student.getLetterScore();

            Assert.AreEqual('C', letterScore);
        }



        [TestMethod]
        public void addFirstStudent_Should_Success()
        {
            StudentService service = new StudentService();
            Student student = new Student() { Id = 1, Age = 20, Name = "Bach", Score = 5.0 };

            bool status = service.addStudent(student);
            Assert.IsTrue(status);
        }

        [TestMethod]
        public void AddDuplicaStudentId_ShouldReturn_False()
        {
            StudentService service = new StudentService();
            Student s1 = new Student() { Id = 1, Age = 30, Name = "Bach", Score = 7.0 };
            Student s2 = new Student() { Id = 1, Age = 30, Name = "Bach", Score = 7.0 };

            service.addStudent(s1);
            bool status = service.addStudent(s2);

            Assert.IsFalse(status);
        }

       
    }
}